using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Collections;
using System.Reflection;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.ComponentModel;
using Microsoft.Ink;
using System.Windows.Forms;

namespace Physics.Collab
{
	public class ClienteRecebe
	{
	    private Socket socket;

        #region ClienteRecebe()
        public ClienteRecebe(Socket s) 
        {
		    this.socket = s;
        }
        #endregion

        #region run()
        public void run ()  
        {
            
    	    try 
            {

                bool clientTalking = true;
                
                //a loop that reads from and writes to the socket
                while (clientTalking) 
                {
            	    //get what client wants to say...
                    
                    byte[] bytes = new byte[8192];
				    int bytesRec = this.socket.Receive(bytes);
					
                    ArrayList list = (ArrayList) getObjectWithByteArray(bytes);          
                    
                    Object o = list[0];
                    String nomeEvento = (String) list[1];
                	

                    // EVENTOS DO ARGO
               	    if (nomeEvento.Equals("PROT_atualiza_modelo_cliente"))
            	    {
                   		
            	    }
                    
               	    if (nomeEvento.Equals("PROT_atualiza_modelo_cliente_inicial"))
            	    {
                			
            	    }
                   	
               	    // Recebeu uma mensagem de chat!
               	    if (nomeEvento.Equals("PROT_chat_msg"))
            	    {

            	    }

    //              Recebeu a notifica��o que algum cliente entrou na da sess�o!
               	    if (nomeEvento.Equals("PROT_inicio_sessao"))
            	    {
            	    }

                   	
    //              Recebeu a notifica��o que algum cliente saiu da sess�o!
               	    if (nomeEvento.Equals("PROT_fim_sessao"))
            	    {
            	    }

                    // Esta a��o foi removida para a experi�ncia
               	    /* if (nomeEvento.equals("ActionDeleteFromDiagram-actionPerformed"))
                	    ActionDeleteFromDiagram.SINGLETON.actionPerformedImpl((ActionEvent) o); */
                    
                    if (nomeEvento.Equals("PROT_remove_elemento"))
                    {
                	    // TODO: ActionRemoveFromModel.SINGLETON.actionPerformedImpl((ArrayList) o);
                    }
                    
               	    if (nomeEvento.StartsWith("SEL_"))
            	    {
               		    // TODO: Verificar selec��o
                        
                        // nomeEvento = nomeEvento.substring(4,nomeEvento.length());
                   		
               		    // SelecionaTool(nomeEvento,o,false);

                        

                        
            	    }

                    // EVENTOS DO GEF

                    // Desenho do TelePointer!
                    #region mouseMovedPointer
                    if (nomeEvento.Equals("mouseMovedPointer"))
                    {
                        
                         
                        /* 
                        // Sem os telePointers por enquanto
                        ArrayList dados = (ArrayList) o;
                        
                        FigPointer fp = Global.main.fpA;
                        String Id_tele  = (String) dados[2];

                        if (Id_tele.Equals("1") ) fp = Global.main.fpA;
                        if (Id_tele.Equals("2") ) fp = Global.main.fpB;
                        if (Id_tele.Equals("3") ) fp = Global.main.fpC;
                        if (Id_tele.Equals("4") ) fp = Global.main.fpD;

                        fp.setCor((Color) dados[1] );
                        fp.setNome((String) dados[3]);
                        
                        fp.setLocation((Point) dados[0]); */

                        

                    }
                    #endregion



                    #region inkoverlay_Stroke
                    if (nomeEvento.Equals("inkoverlay_Stroke"))
                    {
                        ArrayList dados = (ArrayList) o;

                        
                        Ink x = new Ink();
                        x.Load( (byte[]) dados[0] );

                        Stroke s = x.Strokes[x.Strokes.Count-1];
  
                        InkCollectorStrokeEventArgs e = new InkCollectorStrokeEventArgs(null ,s , false);

                        // Precisa utilizar delegates, pois existem problemas quando uma Thread que n�o �
                        // o formul�rio atualiza a interface gr�fica
                        Global.main.Invoke(new MainForm.DelegateToMethod(Global.main.inkoverlay_StrokeImpl),new object[] { e });

                    }

                    #endregion


                }
               	
            } 
            catch (ThreadAbortException  e) 
            {
                MessageBox.Show("ThreadAbortException in ClienteRecebe:" + e.Message  , 
			    Application.ProductName, 
			    MessageBoxButtons.OK, 
			    MessageBoxIcon.Warning);
                return;
            }
            catch (Exception e) 
            {
                MessageBox.Show("Exception in ClienteRecebe:" + e.Message  , 
			    Application.ProductName, 
			    MessageBoxButtons.OK, 
			    MessageBoxIcon.Warning);
            }
        }
        #endregion

        // M�todo que vai empacotar os dados antes deles serem enviados        
        #region getByteArrayWithObject()
        
        public static byte[] getByteArrayWithObject(Object o)
        {
            MemoryStream ms = new MemoryStream();
            BinaryFormatter bf1 = new BinaryFormatter();
            bf1.Serialize(ms, o);
            return ms.ToArray();
        }
        #endregion

        // M�todo que vai desempacotar os dados antes deles serem enviados        
        #region getObjectWithByteArray()
        public static object getObjectWithByteArray(byte[] theByteArray)
        {
            MemoryStream ms = new MemoryStream(theByteArray);
            BinaryFormatter bf1 = new BinaryFormatter();
            ms.Position = 0;

            return bf1.Deserialize(ms);
        }
        #endregion



    }
}
